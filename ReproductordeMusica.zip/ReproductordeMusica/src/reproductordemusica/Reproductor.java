
package reproductordemusica;

// Jose Sebastian Romo - Lina Muñoz Grupo 3

public class Reproductor {
    private Cancion cancionActual; // La canción que se está reproduciendo actualmente
    private boolean reproduciendo; // Indica si la canción se está reproduciendo
    private int volumen; // Nivel de volumen del reproductor

    // Método para reproducir una canción
    public void reproducir(Cancion cancion) {
        this.cancionActual = cancion; // Asigna la canción actual
        this.reproduciendo = true; // Cambia el estado a reproduciendo
        System.out.println("Reproduciendo: " + cancion); // Muestra la canción que se está reproduciendo
    }

    // Método para pausar o reanudar la reproducción
    public void pausarReanudar() {
        if (reproduciendo) { // Si se está reproduciendo
            reproduciendo = false; // Cambia el estado a no reproduciendo
            System.out.println("Reproduccion pausada."); // Muestra mensaje de pausa
        } else if (cancionActual != null) { // Si hay una canción cargada pero no se está reproduciendo
            reproduciendo = true; // Cambia el estado a reproduciendo
            System.out.println("Reproduccion reanudada: " + cancionActual); // Muestra mensaje de reanudación
        } else {
            System.out.println("No hay ninguna cancion reproduciendose."); // Muestra mensaje de error
        }
    }

    // Método para avanzar en la canción actual
    public void avanzar() {
        if (cancionActual != null) { // Si hay una canción cargada
            System.out.println("Avanzando en la cancion: " + cancionActual); // Muestra mensaje de avance
        } else {
            System.out.println("No hay ninguna cancion reproduciendose."); // Muestra mensaje de error
        }
    }

    // Método para retroceder en la canción actual
    public void retroceder() {
        if (cancionActual != null) { // Si hay una canción cargada
            System.out.println("Retrocediendo en la cancion: " + cancionActual); // Muestra mensaje de retroceso
        } else {
            System.out.println("No hay ninguna canción reproduciendose."); // Muestra mensaje de error
        }
    }

    // Método para ajustar el volumen del reproductor
    public void setVolumen(int volumen) {
        if (volumen >= 0 && volumen <= 100) { // Si el volumen está dentro del rango válido
            this.volumen = volumen; // Asigna el nuevo nivel de volumen
            System.out.println("Volumen ajustado a: " + volumen); // Muestra mensaje de ajuste de volumen
        } else {
            System.out.println("El nivel de volumen debe estar entre 0 y 100."); // Muestra mensaje de error
        }
    }
}

