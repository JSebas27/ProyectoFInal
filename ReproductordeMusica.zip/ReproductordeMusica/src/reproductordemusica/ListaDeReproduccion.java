
package reproductordemusica;
//Jose Sebastian Romo - Lina Muñoz Grupo 3
import java.util.ArrayList;
import java.util.List;

public class ListaDeReproduccion {

    private String nombre; // Nombre de la lista de reproducción
    private List<Cancion> canciones; // Lista de canciones en la lista de reproducción

    // Constructor que inicializa la lista de reproducción con un nombre y una lista vacía de canciones
    public ListaDeReproduccion(String nombre) {
        this.nombre = nombre;
        this.canciones = new ArrayList<>();
    }

    // Método para agregar una canción a la lista de reproducción
    public void agregarCancion(Cancion cancion) {
        canciones.add(cancion); // Añade la canción a la lista
    }

    // Método para listar todas las canciones en la lista de reproducción
    public void listarCanciones() {
        if (canciones.isEmpty()) { // Verifica si la lista de canciones está vacía
            System.out.println("No hay canciones en la lista de reproduccion."); // Muestra mensaje si está vacía
        } else {
            System.out.println("Canciones en la lista de reproduccion:"); // Muestra mensaje de inicio de la lista
            for (Cancion cancion : canciones) { // Itera sobre cada canción en la lista
                System.out.println(cancion); // Imprime la información de cada canción
            }
        }
    }
}
