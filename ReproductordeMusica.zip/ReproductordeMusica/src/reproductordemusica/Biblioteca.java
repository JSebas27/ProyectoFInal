
package reproductordemusica;
//Jose Sebastian Romo - Lina Muñoz Grupo 3
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

public class Biblioteca {
    private List<Cancion> canciones; // Lista que almacena las canciones de la biblioteca
    private List<ListaDeReproduccion> listas; // Lista que almacena las listas de reproducción

    // Constructor que inicializa la biblioteca con listas vacías de canciones y listas de reproducción
    public Biblioteca() {
        this.canciones = new ArrayList<>();
        this.listas = new ArrayList<>();
    }

    // Método para agregar una canción a la biblioteca
    public void agregarCancion(Cancion cancion) {
        canciones.add(cancion); // Añade la canción a la lista de canciones
    }

    // Método para listar todas las canciones en la biblioteca
    public void listarCanciones() {
        if (canciones.isEmpty()) { // Verifica si la lista de canciones está vacía
            System.out.println("No hay canciones en la biblioteca."); // Muestra mensaje si está vacía
        } else {
            System.out.println("Canciones en la biblioteca:"); // Muestra mensaje de inicio de la lista
            for (Cancion cancion : canciones) { // Itera sobre cada canción en la lista
                System.out.println(cancion); // Imprime la información de cada canción
            }
        }
    }

    // Método para buscar una canción por su título
    public Cancion buscarCancionPorTitulo(String titulo) {
        for (Cancion cancion : canciones) { // Itera sobre cada canción en la lista
            if (cancion.getTitulo().equalsIgnoreCase(titulo)) { // Compara el título ignorando mayúsculas/minúsculas
                return cancion; // Devuelve la canción si coincide el título
            }
        }
        return null; // Devuelve null si no encuentra la canción
    }

    // Método para buscar canciones que coincidan con un término (en título, artista, álbum o género)
    public void buscarCanciones(String termino) {
        for (Cancion cancion : canciones) { // Itera sobre cada canción en la lista
            if (cancion.getTitulo().contains(termino) || 
                cancion.getArtista().contains(termino) || 
                cancion.getAlbum().contains(termino) || 
                cancion.getGenero().contains(termino)) {
                System.out.println(cancion); // Imprime la canción si coincide el término en cualquiera de sus atributos
            }
        }
    }

    // Método para ordenar las canciones según un criterio especificado
    public void ordenarCanciones(String criterio) {
        // Define un comparador según el criterio de ordenación
        Comparator<Cancion> comparator = switch (criterio.toLowerCase()) {
            case "titulo" -> Comparator.comparing(Cancion::getTitulo);
            case "artista" -> Comparator.comparing(Cancion::getArtista);
            case "album" -> Comparator.comparing(Cancion::getAlbum);
            case "genero" -> Comparator.comparing(Cancion::getGenero);
            default -> null;
        };

        if (comparator != null) {
            canciones.sort(comparator); // Ordena las canciones utilizando el comparador
            listarCanciones(); // Lista las canciones ordenadas
        } else {
            System.out.println("Criterio de ordenación no válido."); // Muestra mensaje si el criterio no es válido
        }
    }

    // Método para eliminar una canción de la biblioteca por su título
    public void eliminarCancion(String titulo) {
        Cancion cancion = buscarCancionPorTitulo(titulo); // Busca la canción por el título
        if (cancion != null) {
            canciones.remove(cancion); // Elimina la canción de la lista
            System.out.println("Canción eliminada: " + cancion); // Muestra mensaje de confirmación
        } else {
            System.out.println("Canción no encontrada."); // Muestra mensaje si no encuentra la canción
        }
    }

    // Método para agregar una lista de reproducción a la biblioteca
    public void agregarListaDeReproduccion(ListaDeReproduccion lista) {
        listas.add(lista); // Añade la lista de reproducción a la lista de listas
    }
}