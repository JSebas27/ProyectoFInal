
package reproductordemusica;
//Jose Sebastian Romo - Lina Muñoz Grupo 3
import java.util.Scanner;

public class ReproductordeMusica {

    static Scanner sc = new Scanner(System.in);
    static Biblioteca biblioteca = new Biblioteca();
    static Reproductor reproductor = new Reproductor();

    public static void main(String[] args) {
        int opcion;
        // Bucle principal del menú
        do {
            System.out.println("--- Reproductor de Música ---");
            System.out.println("0. Salir");
            System.out.println("1. Crear canción");
            System.out.println("2. Agregar canción a la biblioteca");
            System.out.println("3. Listar canciones");
            System.out.println("4. Reproducir canción");
            System.out.println("5. Pausar/reanudar reproducción");
            System.out.println("6. Avanzar canción");
            System.out.println("7. Retroceder canción");
            System.out.println("8. Controlar volumen");
            System.out.println("9. Crear lista de reproducción");
            System.out.println("10. Buscar canciones");
            System.out.println("11. Ordenar canciones");
            System.out.println("12. Eliminar canción");
            System.out.println("---------------------------");
            System.out.print("Ingrese la opción: ");
            opcion = Integer.parseInt(sc.nextLine());

            // Manejo de opciones del menú
            switch (opcion) {
                case 0:
                    System.out.println("Saliendo...");
                    break;
                case 1:
                    System.out.println("---------------------------");
                    crearCancion();
                    break;
                case 2:
                    System.out.println("---------------------------");
                    agregarCancionABiblioteca();
                    break;
                case 3:
                    System.out.println("---------------------------");
                    listarCanciones();
                    break;
                case 4:
                    System.out.println("---------------------------");
                    reproducirCancion();
                    break;
                case 5:
                    System.out.println("---------------------------");
                    pausarReanudarReproduccion();
                    break;
                case 6:
                    System.out.println("---------------------------");
                    avanzarCancion();
                    break;
                case 7:
                    System.out.println("---------------------------");
                    retrocederCancion();
                    break;
                case 8:
                    System.out.println("---------------------------");
                    controlarVolumen();
                    break;
                case 9:
                    System.out.println("---------------------------");
                    crearListaDeReproduccion();
                    break;
                case 10:
                    System.out.println("---------------------------");
                    buscarCancion();
                    break;
                case 11:
                    System.out.println("---------------------------");
                    ordenarCanciones();
                    break;
                case 12:
                    System.out.println("---------------------------");
                    eliminarCancion();
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, ingrese un número válido.");
                    break;
            }
        } while (opcion != 0); // Terminar cuando el usuario ingrese 0
    }

    // Crear una nueva canción
    public static void crearCancion() {
        System.out.println("Ingrese los datos de la canción en el siguiente formato:");
        System.out.println("Titulo&Artista&Album&Genero");
        String datos = sc.nextLine();
        String[] partes = datos.split("&");
        if (partes.length == 4) {
            Cancion cancion = new Cancion(partes[0], partes[1], partes[2], partes[3]);
            System.out.println("Cancion creada: " + cancion);
        } else {
            System.out.println("Error: El formato del texto no es valido. Ingresa los datos en el formato especificado.");
        }
    }

    // Agregar una canción a la biblioteca
    public static void agregarCancionABiblioteca() {
        System.out.println("Ingrese los datos de la cancion a agregar en el siguiente formato:");
        System.out.println("Titulo&Artista&Album&Genero");
        String datos = sc.nextLine();
        String[] partes = datos.split("&");
        if (partes.length == 4) {
            Cancion cancion = new Cancion(partes[0], partes[1], partes[2], partes[3]);
            biblioteca.agregarCancion(cancion);
            System.out.println("Cancion agregada a la biblioteca: " + cancion);
        } else {
            System.out.println("Error: El formato del texto no es valido. Ingresa los datos en el formato especificado.");
        }
    }

    // Listar todas las canciones de la biblioteca
    public static void listarCanciones() {
        biblioteca.listarCanciones();
    }

    // Reproducir una canción
    public static void reproducirCancion() {
        System.out.println("Ingrese el titulo de la cancion a reproducir:");
        String titulo = sc.nextLine();
        Cancion cancion = biblioteca.buscarCancionPorTitulo(titulo);
        if (cancion != null) {
            reproductor.reproducir(cancion);
        } else {
            System.out.println("Cancion no encontrada.");
        }
    }

    // Pausar o reanudar la reproducción
    public static void pausarReanudarReproduccion() {
        reproductor.pausarReanudar();
    }

    // Avanzar a la siguiente canción
    public static void avanzarCancion() {
        reproductor.avanzar();
    }

    // Retroceder a la canción anterior
    public static void retrocederCancion() {
        reproductor.retroceder();
    }

    // Controlar el volumen del reproductor
    public static void controlarVolumen() {
        System.out.println("Ingrese el nuevo nivel de volumen (0-100):");
        int volumen = Integer.parseInt(sc.nextLine());
        reproductor.setVolumen(volumen);
    }

    // Crear una nueva lista de reproducción
    public static void crearListaDeReproduccion() {
        System.out.println("Ingrese el nombre de la nueva lista de reproduccion:");
        String nombre = sc.nextLine();
        ListaDeReproduccion lista = new ListaDeReproduccion(nombre);
        System.out.println("Ingrese los titulos de las canciones a agregar, separados por comas:");
        String titulos = sc.nextLine();
        String[] partes = titulos.split(",");
        for (String titulo : partes) {
            Cancion cancion = biblioteca.buscarCancionPorTitulo(titulo.trim());
            if (cancion != null) {
                lista.agregarCancion(cancion);
            } else {
                System.out.println("Cancion no encontrada: " + titulo);
            }
        }
        biblioteca.agregarListaDeReproduccion(lista);
    }

    // Buscar canciones en la biblioteca
    public static void buscarCancion() {
        System.out.println("Ingrese el termino de búsqueda (titulo, artista, album o genero):");
        String termino = sc.nextLine();
        biblioteca.buscarCanciones(termino);
    }

    // Ordenar las canciones de la biblioteca
    public static void ordenarCanciones() {
        System.out.println("Ingrese el criterio de orden (titulo, artista, album, genero):");
        String criterio = sc.nextLine();
        biblioteca.ordenarCanciones(criterio);
    }

    // Eliminar una canción de la biblioteca
    public static void eliminarCancion() {
        System.out.println("Ingrese el titulo de la cancion a eliminar:");
        String titulo = sc.nextLine();
        biblioteca.eliminarCancion(titulo);
    }
}